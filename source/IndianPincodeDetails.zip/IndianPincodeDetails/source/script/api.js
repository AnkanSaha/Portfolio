// Api for Searching Indian Pincode Details
// 

document.getElementById('validatebtn').addEventListener('click', ()=>{
	let template = "";
	let temppincode = document.getElementById('pincode').value
	const options = {
		method: 'POST',
		headers: {
			'content-type': 'application/json',
			'Content-Type': 'application/json',
			'X-RapidAPI-Host': 'pincode.p.rapidapi.com',
			'X-RapidAPI-Key': 'aefb3fa51fmsha59d973a9f83424p149b2bjsn70bd6dd35de3'
		},
		body: '{"searchBy":"pincode","value":'+temppincode+'}'
	};
	fetch('https://pincode.p.rapidapi.com/', options)
		.then(response => response.json())
		.then(response => response.forEach(element => {
			console.log(element);
			template = `<div class="jumbotron jumbotron-fluid centre">
			<div class="container">
			  <h1 class="display-4">Post office Details</h1>
			  <p class="lead">
				<table>
				  <tr>
					<th>Prifix</th>
					<th>Details</th>
				  </tr>
				  <tr>
					<td>Pincode</td>
					<td>${element.pin}</td>
				  </tr>
				  <tr>
					<td>Office</td>
					<td>${element.office}}</td>
				  </tr>
				  <tr>
					<td>Office-type</td>
					<td>${element.office_type}</td>
				  </tr>
				  <tr>
				  <td>Delivery</td>
				  <td>${element.delivery}</td>
				</tr>
				  <tr>
					<td>Division</td>
					<td>${element.division}</td>
				  </tr>
				  <tr>
					<td>Region</td>
					<td>${element.region}</td>
				  </tr>
				  <tr>
					<td>Circle</td>
					<td>${element.circle}</td>
				  </tr>
				  <tr>
					<td>Taluk</td>
					<td>${element.taluk}</td>
				  </tr>
				  <tr>
					<td>District</td>
					<td>${element.district}</td>
				  </tr>
				  <tr>
					<td>State ID</td>
					<td>${element.state_id}</td>
				  </tr>
				  <tr>
					<td>Phone Number</td>
					<td>${element.phone}</td>
				  </tr>
				  <tr>
					<td>Related Sub-office</td>
					<td>${element.related_suboffice}</td>
				  </tr>
				  <tr>
					<td>Related Head-office</td>
					<td>${element.related_headoffice}</td>
				  </tr>
				</table>
			  </p>
			</div>
			</div>`
			document.getElementById('afterresult').style.display = 'block'
			document.getElementById('resultTable').innerHTML = template;
		}));
		})
		.catch(err => console.error(err));


// const options = {
// 	// 	method: 'POST',
// 	// 	headers: {
// 	// 		'content-type': 'application/json',
// 	// 		'Content-Type': 'application/json',
// 	// 		'X-RapidAPI-Host': 'pincode.p.rapidapi.com',
// 	// 		'X-RapidAPI-Key': 'aefb3fa51fmsha59d973a9f83424p149b2bjsn70bd6dd35de3'
// 	// 	},
// 	// 	body: '{"searchBy":"pincode","value":741504}'
// 	// };
	
// 	// fetch('https://pincode.p.rapidapi.com/', options)
// 	// 	.then(response => response.json())
// 	// 	.then(response => console.log(response))
// 	// 	.catch(err => console.error(err));

// Template

/* <div class="jumbotron jumbotron-fluid centre">
<div class="container">
  <h1 class="display-4">Post office Details</h1>
  <p class="lead">
	<table>
	  <tr>
		<th>Prifix</th>
		<th>Details</th>
	  </tr>
	  <tr>
		<td>Pincode</td>
		<td></td>
	  </tr>
	  <tr>
		<td>Office</td>
		<td></td>
	  </tr>
	  <tr>
		<td>Office-type</td>
		<td></td>
	  </tr>
	  <tr>
		<td>Division</td>
		<td></td>
	  </tr>
	  <tr>
		<td>Region</td>
		<td></td>
	  </tr>
	  <tr>
		<td>Circle</td>
		<td></td>
	  </tr>
	  <tr>
		<td>Taluk</td>
		<td></td>
	  </tr>
	  <tr>
		<td>District</td>
		<td></td>
	  </tr>
	  <tr>
		<td>State ID</td>
		<td></td>
	  </tr>
	  <tr>
		<td>Phone Number</td>
		<td></td>
	  </tr>
	  <tr>
		<td>Related Sub-office</td>
		<td></td>
	  </tr>
	  <tr>
		<td>Related Head-office</td>
		<td></td>
	  </tr>
	</table> 
  </p>
</div>
</div> */