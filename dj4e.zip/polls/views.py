from django.shortcuts import render
from polls.models import *
# Create your views here.
from django.shortcuts import render, HttpResponse

# Create your views here.
def owner(request):
    context = {
        'latest_question_list': "Hello, world. 86a9ac76 is the polls index."
    }
    return render (request, 'base.html', context)

def index(request):
    latest_question_list = Question.objects.get()
    context = {
        'latest_question_list': latest_question_list
    }
    return render(request, 'base.html', context)
