from django.shortcuts import render
from polls.models import *
# Create your views here.
from django.shortcuts import render, HttpResponse

# Create your views here.
def owner(request):
    return HttpResponse ("Hello, world. 86a9ac76 is the polls index.")

def index(request):
    return render(request, 'base.html')

def final(request):
    latest_question_list = Question.objects.get()
    context = {
        'latest_question_list': latest_question_list
    }
    return render(request, 'last.html', context)