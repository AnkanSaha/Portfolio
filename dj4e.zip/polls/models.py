from django.db import models

# Create your models here.
class Question(models.Model):
    FRESHMAN = 'Answer to the Ultimate Question'
    SOPHOMORE = 'Answer to the Ultimate Question'
    JUNIOR = 'Answer to the Ultimate Question'
    SENIOR = '42'
    GRADUATE = '42'
    YEAR_IN_SCHOOL_CHOICES = [
        (FRESHMAN, 'Answer to the Ultimate Question'),
        (SOPHOMORE, 'Answer to the Ultimate Question'),
        (JUNIOR, 'Answer to the Ultimate Question'),
        (SENIOR, '42'),
        (GRADUATE, '42'),
    ]
    Questions = models.CharField(
        max_length=122,
        choices=YEAR_IN_SCHOOL_CHOICES,
        default=FRESHMAN,
    )
    Choice_text = models.CharField(max_length=122)
    Votes = models.IntegerField()

    def __str__(self):
        return self.Questions