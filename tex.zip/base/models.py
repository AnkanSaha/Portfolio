from pyexpat import model
from django.db import models

# Create your models here.
class question(models.Model):
    question = models.CharField(max_length=122)