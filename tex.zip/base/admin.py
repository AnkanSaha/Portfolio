from django.contrib import admin
from base.models import question
# Register your models here.

admin.site.register(question)